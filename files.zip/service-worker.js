/*
  Service Worker — Smit Parekh's PDF Factory
  ------------------------------------------------------------------
  Strategy:
    - App shell (index.html, manifest, icons): cache-first, so the
      tool loads instantly and works fully offline after first visit.
    - Third-party CDN libraries (pdf-lib, pdf.js, jsPDF): stale-while-
      revalidate — serve from cache immediately, refresh in the
      background so updates are picked up without blocking load.
    - Everything else: network-first with a cache fallback.

  Bump CACHE_VERSION whenever index.html (or any shell asset) changes,
  so clients pick up the new version instead of serving a stale copy.
*/

const CACHE_VERSION = 'v1';
const SHELL_CACHE   = `pdf-factory-shell-${CACHE_VERSION}`;
const CDN_CACHE      = `pdf-factory-cdn-${CACHE_VERSION}`;
const RUNTIME_CACHE  = `pdf-factory-runtime-${CACHE_VERSION}`;

const SHELL_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-72.png',
  './icons/icon-96.png',
  './icons/icon-128.png',
  './icons/icon-144.png',
  './icons/icon-152.png',
  './icons/icon-192.png',
  './icons/icon-384.png',
  './icons/icon-512.png',
  './icons/icon-maskable-192.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png'
];

// Third-party library origins we want to cache aggressively for offline use.
const CDN_HOSTS = [
  'cdnjs.cloudflare.com',
  'cdn.jsdelivr.net'
];

/* ─────────────────────────── INSTALL ─────────────────────────── */
self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(SHELL_CACHE);
      // addAll fails the whole install if any single asset 404s, so
      // fetch individually and tolerate misses (e.g. optional icons).
      await Promise.all(
        SHELL_ASSETS.map(async (url) => {
          try {
            const res = await fetch(url, { cache: 'no-cache' });
            if (res.ok) await cache.put(url, res);
          } catch (err) {
            // Non-fatal: asset will simply be fetched from network later.
          }
        })
      );
      self.skipWaiting();
    })()
  );
});

/* ─────────────────────────── ACTIVATE ────────────────────────── */
self.addEventListener('activate', (event) => {
  const validCaches = new Set([SHELL_CACHE, CDN_CACHE, RUNTIME_CACHE]);
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((key) => key.startsWith('pdf-factory-') && !validCaches.has(key))
          .map((key) => caches.delete(key))
      );
      await self.clients.claim();
    })()
  );
});

/* ──────────────────────────── FETCH ──────────────────────────── */
self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // 1) CDN library scripts → stale-while-revalidate
  if (CDN_HOSTS.includes(url.host)) {
    event.respondWith(staleWhileRevalidate(request, CDN_CACHE));
    return;
  }

  // 2) Same-origin navigation / shell assets → cache-first, network fallback
  if (url.origin === self.location.origin) {
    event.respondWith(cacheFirst(request, SHELL_CACHE));
    return;
  }

  // 3) Everything else (other cross-origin GETs) → network-first
  event.respondWith(networkFirst(request, RUNTIME_CACHE));
});

/* ─────────────────────────── STRATEGIES ──────────────────────── */
async function cacheFirst(request, cacheName) {
  const cache  = await caches.open(cacheName);
  const cached = await cache.match(request, { ignoreSearch: true });
  if (cached) return cached;

  try {
    const response = await fetch(request);
    if (response && response.ok) cache.put(request, response.clone());
    return response;
  } catch (err) {
    // Offline and not cached — fall back to the app shell for navigations
    // so a deep link / reload still opens the tool.
    if (request.mode === 'navigate') {
      const shellFallback = await cache.match('./index.html');
      if (shellFallback) return shellFallback;
    }
    throw err;
  }
}

async function networkFirst(request, cacheName) {
  const cache = await caches.open(cacheName);
  try {
    const response = await fetch(request);
    if (response && response.ok) cache.put(request, response.clone());
    return response;
  } catch (err) {
    const cached = await cache.match(request, { ignoreSearch: true });
    if (cached) return cached;
    throw err;
  }
}

async function staleWhileRevalidate(request, cacheName) {
  const cache  = await caches.open(cacheName);
  const cached = await cache.match(request, { ignoreSearch: true });

  const networkFetch = fetch(request)
    .then((response) => {
      if (response && response.ok) cache.put(request, response.clone());
      return response;
    })
    .catch(() => undefined);

  // Serve cached immediately if we have it; otherwise wait on network.
  return cached || (await networkFetch) || Response.error();
}

/* ───────────────────── MESSAGE (manual update) ───────────────── */
self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});
