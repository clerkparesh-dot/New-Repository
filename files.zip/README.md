# PDF Factory — PWA package

## What's in here
```
index.html          ← your tool, with PWA tags added to <head> and a registration
                       script added at the end of <body> (no functional changes)
manifest.json        ← app name, colors, icons, install shortcuts
service-worker.js    ← offline caching (app shell + cached CDN libraries)
browserconfig.xml    ← Windows tile metadata
icons/                ← generated icon set (16–512px, maskable, apple-touch, favicon)
```

## Important: this needs to be served over HTTPS (or localhost)
Service workers and installability **do not work when you open `index.html`
directly from disk** (`file://…`). Browsers require a secure origin. Options:

- **Quick local test:** from this folder run `python3 -m http.server 8080`,
  then open `http://localhost:8080` in Chrome/Edge.
- **Real hosting (free, static):** GitHub Pages, Netlify, Vercel, or
  Cloudflare Pages — drag-and-drop this whole folder (keep the file
  structure exactly as-is; `manifest.json`, `service-worker.js`, and
  `icons/` must sit next to `index.html`).

## Testing the install flow
- **Android / Chrome / Edge (desktop or mobile):** an "⬇️ Install App"
  button appears in the header once the browser fires its install-eligibility
  event; tapping it opens the native install dialog. You can also use the
  browser's own "Install app" menu item.
- **iOS / iPadOS Safari:** Apple doesn't expose an install-prompt API, so
  Safari never fires that event — a banner appears instead telling the user
  to tap **Share → Add to Home Screen**. This is standard iOS behaviour, not
  a bug.
- **Windows:** Edge treats any installed PWA as a Start Menu / taskbar app
  automatically, using `manifest.json` and the Windows tile metadata in
  `browserconfig.xml`.

## Offline behaviour
- On first load, the service worker caches `index.html`, `manifest.json`,
  and all icons (the "app shell"), plus the three CDN libraries
  (pdf-lib, pdf.js, jsPDF) the first time they're fetched.
- On repeat visits — including fully offline — the shell and libraries are
  served from cache instantly (stale-while-revalidate for the CDN scripts,
  so they still quietly re-check for updates in the background when online).
- All PDF processing already happens client-side in the browser (per the
  existing "100% Private – No Upload" badge), so offline use doesn't change
  any privacy behaviour — it only removes the dependency on the CDN being
  reachable.

## Updating the app later
Whenever you change `index.html` (or anything in `icons/`), bump
`CACHE_VERSION` at the top of `service-worker.js` (e.g. `'v1'` → `'v2'`).
That forces browsers to fetch the new shell and discard the old cache on
next load — otherwise users may keep seeing a cached older version.

## Icons
The icon set was generated programmatically (a gradient square matching
your app's existing purple theme, `#6c63ff` → `#a78bfa`, with a simple
document glyph) rather than reusing the 📄 emoji, since PNG icons render
consistently across Windows tiles, Android adaptive icons, and iOS home
screen — emoji glyphs don't. Swap any file in `icons/` for your own artwork
if you'd like a custom logo instead; keep the same filenames and pixel
dimensions so the manifest and `<head>` links don't need updating.
